<?php

namespace Drupal\Core\Database\Driver\mysql;

use Drupal\Core\Database\Query\Merge as QueryMerge;

/**
 * MySQL implementation of \Drupal\Core\Database\Query\Merge.
 */
class Merge extends QueryMerge { }
