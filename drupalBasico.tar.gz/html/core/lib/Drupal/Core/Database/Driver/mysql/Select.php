<?php

namespace Drupal\Core\Database\Driver\mysql;

use Drupal\Core\Database\Query\Select as QuerySelect;

/**
 * MySQL implementation of \Drupal\Core\Database\Query\Select.
 */
class Select extends QuerySelect { }
